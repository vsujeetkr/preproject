/**
 * @file
 * A requestAnimationFrame polyfill.
 *
 * by Erik Möller. fixes from Paul Irish and Tino Zijdel.
 * MIT license
 *
 * @see https://gist.github.com/paulirish/1579671
 */
!function(m){for(var o=0,n=["ms","moz","webkit","o"],e=0;e<n.length&&!m.requestAnimationFrame;++e)m.requestAnimationFrame=window[n[e]+"RequestAnimationFrame"],m.cancelAnimationFrame=window[n[e]+"CancelAnimationFrame"]||window[n[e]+"CancelRequestAnimationFrame"];m.requestAnimationFrame||(m.requestAnimationFrame=function(n,e){var i=(new Date).getTime(),a=Math.max(0,16-(i-o)),t=m.setTimeout(function(){n(i+a)},a);return o=i+a,t}),m.cancelAnimationFrame||(m.cancelAnimationFrame=function(n){clearTimeout(n)})}(this);
